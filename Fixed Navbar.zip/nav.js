const contact = document.querySelector('.contact');
const frag = document.querySelector('.fragment')
let x = 1;
contact.addEventListener ('click', () =>{
  if (x === 1) {
  frag.style.transform   ='translateX(0%)';
  x = 0
  }
  else {
  frag.style.transform   ='translateX(-100%)';
  x = 1;
  }
})